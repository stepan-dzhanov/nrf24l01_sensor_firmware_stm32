#ifndef _AT24C0X_H_
#define _AT24C0X_H_	
	#include "stdint.h"
	#include "I2CdriverTypes.h"
	//---------------------------------------------------------------------------
	typedef struct{
		Type_MyI2cOpStatus (*PageRead)(uint8_t slaveAddr,uint8_t* pBuffer,uint16_t readAddr,uint16_t numByteToRead);
		Type_MyI2cOpStatus (*PageWrite)(uint8_t slaveAddr,uint8_t* pBuffer,uint16_t writeAddr,uint16_t numByteToWrite);
		void (*WaitEepromStandbyState)(uint8_t slaveAddr);
	}Type_AT24C0X_Init;		
	//---------------------------------------------------------------------------
	void AT24C0X_Init(Type_AT24C0X_Init *s);
	Type_MyI2cOpStatus AT24C0X_BufferWrite(uint8_t* pBuffer, uint16_t writeAddr, u16 NumByteToWrite);
	Type_MyI2cOpStatus AT24C0X_BufferRead(uint8_t* pBuffer, uint16_t readAddr, u16 NumByteToRead);	
	Type_MyI2cOpStatus AT24C0X_Erase(void);
#endif//_AT24C0X_H_
